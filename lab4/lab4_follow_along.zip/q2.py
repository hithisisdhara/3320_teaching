# DO NOT DELETE EXISTING CODE LINES ABOVE DOTTED LINE AT THE END OF FILE
# FIll your code only in the given boxes
string = "Please enter an integer"
goodstrging = "Thank you for listening!"
badstring = "I told you, "

print(string)
#######################
# Fill your code here, use as many new lines you like. Delete this line. 
# read input string with raw_input()
#try
    #
#except
    #
#######################
#--------------------------------------------------------------
'''
Expected outcome:

>> python q2.py
Please enter an integer
>> 1
Thank you for listening!
>>

>> python q2.py
Please enter an integer
>> a
I told you, Please enter an integer
>>
'''

