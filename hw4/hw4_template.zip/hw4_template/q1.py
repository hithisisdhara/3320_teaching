# DO NOT DELETE EXISTING CODE LINES ABOVE DOTTED LINE AT THE END OF FILE
# FIll your code only in the given boxes 
print("Hi there")
print("enter a line in the stdio")
#######################
# Fill your code here, use as many new lines you like. Delete this line.  

#######################
print("echoing you ~~")
#######################
# Fill your code here, use as many new lines you like. Delete this line.
# read input string with raw_input()
#######################

#--------------------------------------------------------------
'''
Expected outcome:
>> python q1.py
Hi there
enter a line in the stdio
>> abc1
echoing you ~~
abc1
>>
'''


