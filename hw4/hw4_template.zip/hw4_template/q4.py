# DO NOT DELETE EXISTING CODE LINES unless told to do so in the comments

print("sum of all integers below 1000 that are multiples of 3 or 5")
sum = 0
#######################
# Fill your code here, use as many new lines you like. Delete this line.
# you will get a zero if you hardcode the sum value 
#######################
print(sum)
#--------------------------------------------------------------
'''
Expected outcome:
>> python q4.py
sum of all integers below 1000 that are multiples of 3 or 5
233168
>>
'''
